package com.example.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.example.main.dao.AdminDao;
import com.example.main.email_token.ConfirmationToken;
import com.example.main.email_token.EmailSenderService;
import com.example.main.model.CommonFeedback;
import com.example.main.model.Coupon;
import com.example.main.model.CustomerDetails;
import com.example.main.model.MerchantDetails;
import com.example.main.model.Product;
import com.example.main.model.ProductFeedback;
import com.example.main.repository.ConfirmationTokenRepository;
import com.example.main.repository.CouponRepository;
import com.example.main.repository.MerchantRepository;

@Service
@Transactional
public class AdminServiceImpl implements AdminService{

	org.slf4j.Logger logger = LoggerFactory.getLogger(AdminServiceImpl.class);
	
	@Autowired
	private AdminDao adminDao;
	
	@Autowired
	ConfirmationTokenRepository confirmationTokenRepository;
	
	@Autowired
	MerchantRepository merchantRepository;
	
	@Autowired
	CouponRepository couponRepo;
	
	@Autowired
	EmailSenderService emailSenderService;

	//Merchant: 
	@Override
	public MerchantDetails addMerchant(MerchantDetails m) {
		logger.trace("Add Merchant working...");
		return adminDao.addMerchant(m);
		
	}

	@Override
	public void removeMerchantById(int merchantId) {
		logger.trace("Remove Merchant working...");
		adminDao.removeMerchantById(merchantId);
	}
	

	@Override
	public List<MerchantDetails> getAllMerchant() {
		logger.trace("Get All Merchant working...");
		List<MerchantDetails> merchants=new ArrayList<MerchantDetails>();
		adminDao.findAllMerchants().forEach(merchants::add);
		return merchants;
	}

	@Override
	public boolean updateMerchant(MerchantDetails updatedMerchant) {
		logger.trace("Update Merchant working...");
		return adminDao.updateMerchant(updatedMerchant);
	}

	@Override
	public MerchantDetails findMerchantById(int userId) {
		logger.trace("Find Merchant By Id working...");
		return adminDao.findMerchantById(userId);
	}
	
	public MerchantDetails verifyMerchantDetails(String email) {
		logger.trace("Verify Merchant Details working...");
		return adminDao.findMerchantByeMail(email);
	}


	public MerchantDetails getApproval(String email, boolean approved) {
		logger.trace("Get Approval working...");
		MerchantDetails merchant = adminDao.findMerchantByeMail(email);
		merchant.setApproved(approved);
		adminDao.addMerchant(merchant);
		return merchant;
	}
	
	
	public List<MerchantDetails> getMerchants() {
		logger.trace("Get Merchants working...");
		List<MerchantDetails> merchant = new ArrayList<>();
		adminDao.findAllMerchants().forEach(merchant::add);
		return merchant;
	}

	
	
	//Product:
	@Override
	public Product addProduct(Product product) {
		logger.trace("Add Product working...");
		return adminDao.addProduct(product);
	}

	@Override
	public boolean removeProduct(int productId) {
		logger.trace("Remove Product working...");
		return adminDao.removeProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {
		logger.trace("Get All Products working...");
		return adminDao.getAllProducts();
	}

	@Override
	public Product getProductByProductId(int productId) {
		logger.trace("Get Product By Id working...");
		return adminDao.getProductByProductId(productId);
	}

	@Override
	public boolean update(Product product) {
		logger.trace("Update Product working...");
		return adminDao.update(product);
	}

	@Override
	public boolean updateCategoryByCategory(String productCategory, String updatedCategory) {
		logger.trace("Update Category working...");
		return adminDao.updateCategoryByCategory(productCategory, updatedCategory);
	}
	
	
	//Customer:

	@Override
	public void removeCustomerById(int userId) {
		logger.trace("Remove Customer By Id working...");
		adminDao.removeCustomerById(userId);
	}


	@Override
	public CustomerDetails findCustomerById(int userId) {
		logger.trace("Find Customer By Id working...");
		return adminDao.findCustomerById(userId);
	}

	@Override
	public CustomerDetails findCustomerByName(String name) {
		logger.trace("Find Customer By Name working...");
		return adminDao.findCustomerByName(name);
	}

	@Override
	public List<CustomerDetails> getAllCustomers() {
		logger.trace("Get All Customers working...");
		return adminDao.getAllCustomers();
	}
	
	
	
	//CommonFeedback:
	@Override
	public List<CommonFeedback> getAllCommonFeedbackByUserId(int userId) {
		logger.trace("Get All Common Feedback by User Id working...");
		return adminDao.getAllCommonFeedbackByUserId(userId);
	}

	@Override
	public CommonFeedback getCommonFeedbackById(int feedbackId) {
		logger.trace("Get Common Feedback By Id working...");
		return adminDao.getCommonFeedbackById(feedbackId);
	}
	
	@Override
	public List<CommonFeedback> getAllCommonFeedbackByProductId(int productId) {
		logger.trace("Get All Common Feedback By Product Id working...");
		return adminDao.getAllCommonFeedbackByProductId(productId);
	}

	@Override
	public int forwardRequestToMerchant(int feedbackId) {
		return adminDao.forwardRequestToMerchant(feedbackId);
	}

	@Override
	public String forwardResponseToCustomer(int feedbackId) {
		logger.trace("Forward Response to Customer working...");
		return adminDao.forwardResponseToCustomer(feedbackId);
	}
	
	@Override
	public List<CommonFeedback> getAll() {
		logger.trace("Get All Common Feedback working...");
		return adminDao.getAll();
	}

	
	
	//ProductFeedback:
	
	@Override
	public void removeProductFeedbackkById(int feedbackId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeProductFeedbackByUserId(int userId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ProductFeedback> getAllProductFeedbackByUserId(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProductFeedback getProductFeedbackById(int feedbackId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ProductFeedback> getProductFeedbackByProductId(int productId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	@Override
	public ProductFeedback addCommonFeedback(ProductFeedback pfd) {
		// TODO Auto-generated method stub
		return null;
	}
	
	//Coupon:
	

	@Override
	public List<Coupon> getCoupons() {
		logger.trace("Get Coupons working...");
		List<Coupon> coupon = new ArrayList<>();
		couponRepo.findAll().forEach(coupon::add);
		return coupon;
	}

	@Override
	public Coupon getCouponById(int couponId) throws Exception {
		logger.trace("Get Coupon By Id working...");
		Coupon coupon = couponRepo.findById(couponId)
				.orElseThrow(() -> new Exception("Coupon not found for this id : " + couponId));
		return coupon;
	}

	@Override
	public Coupon getCouponByCode(String couponCode) {
		logger.trace("Get Coupon By Code working...");
		Coupon coupon = couponRepo.findByCouponCode(couponCode);
		return coupon;
	}

	@Override
	public void addCoupon(@Valid Coupon coupon) throws MessagingException {
		logger.trace("Add Coupon working...");
		couponRepo.save(coupon);
        
			long cnt=merchantRepository.count();
			List <MerchantDetails> merchants=merchantRepository.findAll();
        MimeMessage mailMessage = emailSenderService.createMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mailMessage, true);
        String url = "http://localhost:4200/applyCoupon/"+coupon.getCouponId();
        
       
        	for(MerchantDetails mer:merchants) {
        		helper.setTo(mer.geteMail());
        		System.out.println(mer.geteMail());
        		helper.setSubject("Coupon Creation Approval!");
                helper.setText("<html><body><h1>Coupon Registration!</h1><br>" +
          			  coupon+"<br><button type='submit' class='is-small btn btn-info'>"
    		  		+ "<a href="+url+"/"+mer.getUserId()+">Show Details</a></button>",true);
                
                emailSenderService.sendEmail(mailMessage);
        	}
	}

	@Override
	public Coupon generateCoupon(int couponId, int id) throws Exception {
		logger.trace("Generate Coupon working...");
		Coupon coupon = couponRepo.findById(couponId)
    			.orElseThrow(() -> new Exception("Coupon not found for this id : " + couponId));
    	
        ConfirmationToken confirmationToken = new ConfirmationToken(coupon.getUserId());
       confirmationTokenRepository.save(confirmationToken);
        
        MerchantDetails merchant = merchantRepository.findById(id)
        		.orElseThrow(()->new Exception("Merchant not found for this id : " + coupon.getUserId()));
        
        coupon.setApproved(true);
        coupon.setUseId(id);
        couponRepo.save(coupon);
        merchantRepository.save(merchant);
        
        MimeMessage mailMessage = emailSenderService.createMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mailMessage, true);
        String url = "http://localhost:4200/sendCoupon/"+coupon.getCouponId();
        helper.setTo("dsonaje6@gmail.com");
        helper.setSubject("Coupon Accepted!");
        helper.setFrom("capstore06@gmail.com");
        helper.setText("Merchant accepted coupon offer: "+coupon+"\nTo send this offer, please click here : "
        +"\n"+url);

        emailSenderService.sendEmail(mailMessage);
		return coupon;
	}

	@Override
	public Coupon sendCoupon(int couponId) throws Exception {
		logger.trace("Send Coupon working...");
		Coupon coupon = couponRepo.findById(couponId)
    			.orElseThrow(() -> new Exception("Coupon not found for this id : " + couponId));
        
        MimeMessage mailMessage = emailSenderService.createMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mailMessage, true);
        String url = "http://localhost:4200/productpage/";
        
        List <MerchantDetails> merchants = merchantRepository.findAll();
        
        for(MerchantDetails mer:merchants) {
    		helper.setTo(mer.geteMail());
    		helper.setSubject("Latest Offers!!!");
            helper.setFrom("capstore06@gmail.com");
            helper.setText("Current Offers: "+coupon+"\nGrab this offer, please click here : "
            +"\n"+url);

            emailSenderService.sendEmail(mailMessage);
    	}
        return coupon;
	}

	@Override
	public Boolean deleteCoupon(int couponId) {
		logger.trace("Delete Coupon working...");
		boolean exists = couponRepo.existsById(couponId);
		couponRepo.deleteById(couponId);
		return true;
	}


}
