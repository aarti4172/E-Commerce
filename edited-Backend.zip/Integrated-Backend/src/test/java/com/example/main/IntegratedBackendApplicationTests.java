package com.example.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegratedBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
