import { FilterMerchantPipe } from './filter-merchant.pipe';

describe('FilterMerchantPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterMerchantPipe();
    expect(pipe).toBeTruthy();
  });
});
