export class UserAddress{
    addressId:number;
    address_line1:String;
    address_line2:String;
    district:String;
    state:String;
    landmark:String;
    pincode:number;
   // user_id:number;
    
    
    
}