export class Cart{

    cartId:number;
    //user_id:number;
    type:String;
    productId:number;
    quantity:number;

}