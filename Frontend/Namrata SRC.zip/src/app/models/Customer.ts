export class Customer{
    Cust_Id: Number;
	Cust_Username: String;
    Cust_Password: String;
	Name: String;
	PhoneNo : String;
	Alternate_phone_no : String;
    alternate_email:String;
    
    /*
    Set<Order> orders;
	Set<Address> addresses;
	Set<CommonFeedback> feedbacks;	
	Set<ProductFeedback> productFeedbacks;
	Set<WishList/Cart> list;

    */

}