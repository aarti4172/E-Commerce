export class Promocode{
    
}