export class Merchant{
    Merchant_id:Number;
    Username: String ;
	Name: String;
	PhoneNo : String;
	Alternate_phone_no : String;
    alternate_email:String;
    isApproved:boolean;
    Rating : number;
    /*Set<Order> orders;
	Set<Address> addresses;
	Set<Coupon> coupons;
	Set<Product> products;
    Set<CommonFeedback> feedbacks;
    */

}