export class Coupon{
    
    coupon_id:number;
    coupon_code:String;
    user_id:number;
    end_date:Date;
    start_date:Date;
    coupon_amount:number;
    min_order_amount:number;
    issued_by:String;
}