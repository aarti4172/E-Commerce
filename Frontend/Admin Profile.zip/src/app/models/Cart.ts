export class Cart{

    cart_id:number;
    user_id:number;
    type:String;
    product_id:number;
    product_quantity:number;

}