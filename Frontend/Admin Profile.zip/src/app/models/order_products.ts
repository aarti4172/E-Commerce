export class order_products{
    user_id:number;
    product_id:number;
}