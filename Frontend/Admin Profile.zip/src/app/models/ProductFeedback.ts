export class ProductFeedback{

    feedback_Id:number;
    feedback_subject:String;
    feedback_message:String;
    product_id:String;
    user_id:String;
}