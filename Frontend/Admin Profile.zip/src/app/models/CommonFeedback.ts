export class CommonFeedback{

    feedback_id:number;
    feedback_subject:String;
    feedback_message:String;
    user_id:number;

}